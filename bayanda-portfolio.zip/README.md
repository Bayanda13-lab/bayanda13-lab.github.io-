# Bayanda Vundla Portfolio

Responsive external portfolio website for Cloud Administration, Cybersecurity, Networking and IT Support.

## Deploy to GitHub Pages

1. Put `index.html`, `style.css`, and `script.js` in the repository root.
2. Commit and push to `main`.
3. GitHub → **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Save.

Project-site URL:
`https://bayanda13-lab.github.io/bayanda13-lab.github.io-/`
